# Kamu Radarı

Kamu ilanlarını listeleyen, profile göre uygunluk kontrolü yapan Android uygulaması (Capacitor).

## APK nasıl alınır
1. Bu klasörün içeriğini bir GitHub reposuna yükleyin (`main` dalı).
2. GitHub'da **Actions → APK Olustur** iş akışı otomatik çalışır (veya "Run workflow").
3. İş bitince sayfanın altındaki **Artifacts → kamu-radar-apk** dosyasını indirin, içinden `app-debug.apk` çıkar.
4. APK'yı telefonda açıp "bilinmeyen kaynaklardan yükleme"ye izin verin.

## İlanları güncelleme
- `www/ilanlar.json` dosyasındaki veriler ÖRNEKTİR. Kendi ilanlarınızı aynı biçimde ekleyin.
- Ya da JSON'u GitHub'da yayınlayıp uygulamada **Ayarlar** sekmesine Raw adresini yazın; APK'yı yeniden derlemeniz gerekmez.
- Başvurular her zaman resmî sitelerden yapılır (Kariyer Kapısı, ilan.gov.tr, ÖSYM).

## Logo
`assets/` klasöründeki görseller GitHub Actions sırasında `@capacitor/assets` ile uygulama simgesi ve açılış ekranına dönüştürülür. Logoyu değiştirmek için `assets/icon-only.png` (1024x1024) dosyasını değiştirin.

## Bildirimler
Uygulama **yerel bildirim** kullanır: yeni ilan listeye düştüğünde (uygulama açılıp liste yenilendiğinde) ve "Takvime ekle" ile kurulan son başvuru hatırlatmalarında (son günden 1 gün önce 09:00) bildirim gelir. Uygulama kapalıyken sunucudan anlık push için Firebase (FCM) ve bir sunucu gerekir.

## Bulut yedek (Firebase)
1. console.firebase.google.com → proje oluşturun → **Authentication → E-posta/Şifre**'yi etkinleştirin.
2. **Firestore Database** oluşturun, Kurallar sekmesine yapıştırın:
```
rules_version = '2';
service cloud.firestore { match /databases/{d}/documents {
  match /users/{uid} { allow read, write: if request.auth != null && request.auth.uid == uid; }
}}
```
3. Proje ayarları → Web uygulaması ekleyin; `apiKey` ve `projectId` değerlerini `www/firebase-config.js` içine yazın, repoya yükleyin.
4. Uygulamada Profil → Bulut yedek'ten kayıt olun. Yeni cihazda giriş yapınca profil boşsa yedek otomatik yüklenir.

## Soru-Cevap (Firestore kuralları)
Bulut yedek kurallarına şunu ekleyin:
```
match /ilanlar/{ilan}/yorumlar/{y} {
  allow read: if request.auth != null;
  allow create: if request.auth != null && request.resource.data.uid == request.auth.uid && request.resource.data.metin.size() <= 500;
  allow delete: if request.auth != null && resource.data.uid == request.auth.uid;
}
```
Uygunsuz yorumları Firebase konsolundan silebilirsiniz. Google Play, kullanıcı içeriği için raporlama/engelleme ister; yayına almadan önce eklenmesi gerekir.

## Reklam ve Premium
- AdMob **test** kimlikleri kullanılıyor. Yayın için: AdMob'da uygulama ve banner birimi oluşturun; `www/firebase-config.js` içindeki `banner` değerini, `.github/workflows/android.yml` içindeki `ca-app-pub-...~...` uygulama kimliğini değiştirin, `test:false` yapın.
- Premium bayrağı hazır; gerçek satın alma için Google Play Console'da ürün ve bir Play Billing eklentisi gerekir. `ADS.product` ürün kimliğidir.
