// Firebase konsolundan: Proje ayarları > Genel > Web uygulaması
window.FB={apiKey:"",projectId:""};
// AdMob: test reklam kimliği. Yayına almadan önce kendi banner birim kimliğinizle değiştirin ve test:false yapın.
window.ADS={banner:"ca-app-pub-3940256099942544/6300978111",test:true,product:""};
